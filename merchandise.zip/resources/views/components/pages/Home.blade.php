<x-HomeLayout :title="$title ?? ''">
    <section class="slider_section">
        <div id="customCarousel1" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                @php $active = true; @endphp
                @foreach ($spanduk as $marsyi)
                    @if ($marsyi->active)
                        <div class="carousel-item {{ $active ? 'active' : '' }}">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-7 col-lg-6">
                                        <div class="detail-box">
                                            <h1>{{ $marsyi->title }}</h1>
                                            <p>{{ $marsyi->description }}</p>
                                            <div class="btn-box">
                                                @if ($marsyi->link)
                                                    <a href="{{ $marsyi->link }}" class="btn1">
                                                        Kunjungi
                                                    </a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @php $active = false; @endphp
                    @endif
                @endforeach
            </div>
            <div class="container">
                <ol class="carousel-indicators">
                    @foreach ($spanduk as $index => $marsyi)
                        @if ($marsyi->active)
                            <li data-target="#customCarousel1" data-slide-to="{{ $index }}"
                                class="{{ $index == 0 ? 'active' : '' }}"></li>
                        @endif
                    @endforeach
                </ol>
            </div>
        </div>
    </section>
    @if ($title = 'Beranda')
        </div>
        </header>
    @endif

    <!-- end slider section -->

    <section id="katalog" class="food_section layout_padding-bottom" style="margin-top: 30px">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>
                    Katalog Merchandise
                </h2>
            </div>

            <ul class="filters_menu">
                <li class="active" data-filter="*">Semua</li>
                <li data-filter=".t-shirt">T-Shirt</li>
                <li data-filter=".book">Book</li>
                <li data-filter=".merchandise">Merchandise</li>
            </ul>

            <div class="filters-content">
                <div class="row grid">
                    @foreach ($catalogue as $marsyi)
                        <div class="col-sm-6 col-lg-4 all {{ $marsyi->category }}">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img src="{{ asset('storage/catalogue/' . $marsyi->image) }}" alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            {{ $marsyi->title }}
                                        </h5>
                                        <p>
                                            {{ $marsyi->description }}
                                        </p>
                                        <div class="options">
                                            <h6>
                                                IDR. {{ $marsyi->price }}
                                            </h6>
                                            <a
                                                href="https://wa.me/6287766304421?text={{ urlencode("assalamualaikum min, saya mau pesan product '" . $marsyi->title . "' dengan harga Rp." . $marsyi->price) }}">
                                                <i class="fa fa-cart-shopping" style="color:#EBF4F6;"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="btn-box">
                    <a href="/catalogue">
                        View More
                    </a>
                </div>
            </div>
        </div>
    </section>


    <section id="client" class="client_section layout_padding-bottom">
        <div class="container">
            <div class="heading_container heading_center psudo_white_primary mb_45">
                <h2>
                    Apa yang mereka katakan?
                </h2>
            </div>
            <div class="carousel-wrap row ">
                <div class="owl-carousel client_owl-carousel">
                    @foreach ($customer as $marsyi)
                        <div class="item">
                            <div class="box">
                                <div class="detail-box">
                                    <p>
                                        {{ $marsyi->said }}
                                    </p>
                                    <h6>
                                        {{ $marsyi->title }}
                                    </h6>
                                    <p>
                                        - {{ $marsyi->name }}
                                    </p>
                                </div>
                                <div class="img-box">
                                    <img src="{{ asset('storage/customer/' . $marsyi->image) }}" alt=""
                                        class="box-img">
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>

    <section class="about_section layout_padding">
        <div class="container  ">

            <div class="row">
                <div class="col-md-6 ">
                    <div class="img-box">
                        <img src="{{ asset('assets/images/design.png') }}" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-box">
                        <div class="heading_container">
                            <h2>
                                Santripasir Merchandise
                            </h2>
                        </div>
                        <p>
                            There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration
                            in some form, by injected humour, or randomised words which don't look even slightly
                            believable. If you
                            are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything
                            embarrassing hidden in
                            the middle of text. All
                        </p>
                        <a href="">
                            Tata cara pemesanan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-HomeLayout>
