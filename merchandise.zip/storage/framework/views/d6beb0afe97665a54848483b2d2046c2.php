<?php if (isset($component)) { $__componentOriginala27e7376be9c6cc2d37c630c924d2d84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala27e7376be9c6cc2d37c630c924d2d84 = $attributes; } ?>
<?php $component = App\View\Components\StoryLayout::resolve(['title' => $title ?? ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('StoryLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StoryLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="page-top"></div>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#"><?php echo e($story->title); ?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/story">Story</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="wrapper container">
        <div class="content">
            <div class="row">
                <div class="col-lg-4 col-md-12 mb-4">
                    <img src="<?php echo e(asset('storage/story/' . $story->image)); ?>"
                        alt="deco" class="img-fluid">
                </div>
                <div class="col-lg-8 col-md-12 mb-4 d-flex align-items-center">
                    <p><?php echo $story->body; ?></p>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala27e7376be9c6cc2d37c630c924d2d84)): ?>
<?php $attributes = $__attributesOriginala27e7376be9c6cc2d37c630c924d2d84; ?>
<?php unset($__attributesOriginala27e7376be9c6cc2d37c630c924d2d84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala27e7376be9c6cc2d37c630c924d2d84)): ?>
<?php $component = $__componentOriginala27e7376be9c6cc2d37c630c924d2d84; ?>
<?php unset($__componentOriginala27e7376be9c6cc2d37c630c924d2d84); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/StoryDetail.blade.php ENDPATH**/ ?>