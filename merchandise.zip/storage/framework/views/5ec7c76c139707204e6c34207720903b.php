<?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            title: "Berhasil!",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            confirmButtonText: "Okey",
            customClass: {
                confirmButton: "btn btn-success"
            },
            buttonsStyling: false
        });
    </script>
<?php elseif($errors->any()): ?>
    <script>
        Swal.fire({
            title: "Gagal!",
            html: "<ul>" +
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<li><?php echo e($error); ?></li>" +
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                "</ul>",
            icon: "error",
            confirmButtonText: "Okey",
            customClass: {
                confirmButton: "btn btn-danger"
            },
            buttonsStyling: false
        });
    </script>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/atoms/Alert.blade.php ENDPATH**/ ?>