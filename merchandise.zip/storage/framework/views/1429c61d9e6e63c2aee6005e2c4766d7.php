    <div class="modal fade" id="AddModalSpanduk" tabindex="-1" role="dialog" aria-labelledby="AddModalSpanduk"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/store/spanduk" method="POST">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div>
                                <label for="defaultFormControlInput" class="form-label">Judul</label>
                                <input type="text" class="form-control" id="defaultFormControlInput" name="title"
                                    placeholder="Judul" aria-describedby="defaultFormControlHelp" value="<?php echo e(old('title')); ?>"/>
                            </div>
                            <div>
                                <label for="defaultFormControlInput" class="form-label">Deskripsi</label>
                                <input type="text" class="form-control" id="defaultFormControlInput" name="description"
                                    placeholder="Deskripsi" aria-describedby="defaultFormControlHelp" value="<?php echo e(old('description')); ?>"/>
                            </div>
                            <div>
                                <label for="defaultFormControlInput" class="form-label">Link</label>
                                <input type="text" class="form-control" id="defaultFormControlInput" name="link"
                                    placeholder="Link" aria-describedby="defaultFormControlHelp" value="<?php echo e(old('link')); ?>"/>
                            </div>
                
                        </div>
                    </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\laravel\merchandise\resources\views/components/molecules/AddmodalSpanduk.blade.php ENDPATH**/ ?>