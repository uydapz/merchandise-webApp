<!-- resources/views/search/results.blade.php -->
<?php if (isset($component)) { $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $attributes; } ?>
<?php $component = App\View\Components\HomeLayout::resolve(['title' => $title] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('HomeLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="blog spad">
        <div class="container mb-2">
            <div class="row">
                <div class="col-md-12">
                    <style>
                        .search-container {
                            display: flex;
                            justify-content: center;
                            margin: 20px 0;
                        }
            
                        .search-form {
                            display: flex;
                            align-items: center;
                        }
            
                        .search-input {
                            padding: 10px;
                            font-size: 16px;
                            border: 1px solid #ccc;
                            border-radius: 12px 0 0 12px;
                            flex: 1;
                        }
            
                        .search-button {
                            padding: 10px 20px;
                            font-size: 16px;
                            border: none;
                            background-color: #4F6F52;
                            border-radius: 0 4px 4px 0;
                            color: #F5EFE6;
                            cursor: pointer;
                            transition: background-color 0.2s;
                        }
            
                        .search-button:hover {
                            color: #F5EFE6;
                            background-color: #1A4D2E;
                        }
                    </style>
                    <div class="search-container">
                        <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form">
                            <input type="text" name="query" class="search-input" placeholder="Cari artikel...">
                            <button type="submit" class="search-button"><i class="fa fa-magnifying-glass"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="section-title">
                <h6> - Hasil Pencarian untuk : "<?php echo e($query); ?>"</h1>
            </div>
            <?php if($results->isEmpty()): ?>
                <p>Tidak ada hasil ditemukan.</p>
            <?php else: ?>
                <div class="row">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <?php echo $__env->make('components.atoms.StoryCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($results->links()); ?>

            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $attributes = $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $component = $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/Result.blade.php ENDPATH**/ ?>