<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve(['title' => $title ?? ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('DashboardLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="col-lg-12 mb-4 order-0">
        <div class="card">
            <div class="d-flex align-items-end row">
                <div class="col-sm-7">
                    <div class="card-body">
                        <h3 class="card-title text-primary" id="dynamic-greeting"></h5>
                    </div>
                </div>
                <div class="col-sm-5 text-center text-sm-left">
                    <div class="card-body pb-0 px-0 px-md-4">
                        <img src="<?php echo e(asset('/adminassets/img/illustrations/man-with-laptop-light.png')); ?>" height="140"
                            alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png" />
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>

<script>
    function updateGreeting() {
        const now = new Date();
        const hours = now.getHours();
        let greeting = "";

        if (hours >= 5 && hours < 12) {
            greeting = "Selamat Pagi Tuan " + "<?php echo e(Auth::user()->username); ?>";
        } else if (hours >= 12 && hours < 15) {
            greeting = "Selamat Siang Tuan " + "<?php echo e(Auth::user()->username); ?>";
        } else if (hours >= 15 && hours < 18) {
            greeting = "Selamat Sore Tuan " + "<?php echo e(Auth::user()->username); ?>";
        } else {
            greeting = "Selamat Malam Tuan " + "<?php echo e(Auth::user()->username); ?>";
        }

        document.getElementById("dynamic-greeting").innerText = greeting;
    }

    window.onload = updateGreeting;
</script>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/Dashboard.blade.php ENDPATH**/ ?>