<?php if (isset($component)) { $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $attributes; } ?>
<?php $component = App\View\Components\HomeLayout::resolve(['title' => $title] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('HomeLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    </div>
    </header>
    <style>
        .pagination-container {
            display: flex;
            justify-content: center;
            /* Memusatkan pagination secara horizontal */
            margin-top: 20px;
            /* Jarak atas untuk memberikan spasi */
        }
    </style>
    <section id="katalog" class="food_section layout_padding-bottom" style="margin-top: 30px">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>
                    Katalog Merchandise
                </h2>
            </div>

            <ul class="filters_menu">
                <li class="active" data-filter="*">Semua</li>
                <li data-filter=".t-shirt">T-Shirt</li>
                <li data-filter=".book">Book</li>
                <li data-filter=".merchandise">Merchandise</li>
            </ul>

            <div class="filters-content">
                <div class="row grid">
                    <?php $__currentLoopData = $catalogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-4 all <?php echo e($marsyi->category); ?>">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img src="<?php echo e(asset('storage/catalogue/' . $marsyi->image)); ?>" alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <?php echo e($marsyi->title); ?>

                                        </h5>
                                        <p>
                                            <?php echo e($marsyi->description); ?>

                                        </p>
                                        <div class="options">
                                            <h6>
                                                IDR. <?php echo e($marsyi->price); ?>

                                            </h6>
                                            <a href="<?php echo e($marsyi->link); ?>">
                                                <i class="fa fa-cart-shopping" style="color:#EBF4F6;"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="pagination-container">
                <?php echo e($catalogue->links()); ?>

            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $attributes = $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $component = $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/Catalogue.blade.php ENDPATH**/ ?>