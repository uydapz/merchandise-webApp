<?php if (isset($component)) { $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $attributes; } ?>
<?php $component = App\View\Components\HomeLayout::resolve(['title' => $title ?? ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('HomeLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="slider_section">
        <div id="customCarousel1" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $active = true; ?>
                <?php $__currentLoopData = $spanduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($marsyi->active): ?>
                        <div class="carousel-item <?php echo e($active ? 'active' : ''); ?>">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-7 col-lg-6">
                                        <div class="detail-box">
                                            <h1><?php echo e($marsyi->title); ?></h1>
                                            <p><?php echo e($marsyi->description); ?></p>
                                            <div class="btn-box">
                                                <?php if($marsyi->link): ?>
                                                    <a href="<?php echo e($marsyi->link); ?>" class="btn1">
                                                        Kunjungi
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php $active = false; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="container">
                <ol class="carousel-indicators">
                    <?php $__currentLoopData = $spanduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($marsyi->active): ?>
                            <li data-target="#customCarousel1" data-slide-to="<?php echo e($index); ?>"
                                class="<?php echo e($index == 0 ? 'active' : ''); ?>"></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        </div>
    </section>
    <?php if($title = 'Beranda'): ?>
        </div>
        </header>
    <?php endif; ?>

    <!-- end slider section -->

    <section id="katalog" class="food_section layout_padding-bottom" style="margin-top: 30px">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>
                    Katalog Merchandise
                </h2>
            </div>

            <ul class="filters_menu">
                <li class="active" data-filter="*">Semua</li>
                <li data-filter=".t-shirt">T-Shirt</li>
                <li data-filter=".book">Book</li>
                <li data-filter=".merchandise">Merchandise</li>
            </ul>

            <div class="filters-content">
                <div class="row grid">
                    <?php $__currentLoopData = $catalogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-4 all <?php echo e($marsyi->category); ?>">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img src="<?php echo e(asset('storage/catalogue/' . $marsyi->image)); ?>" alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <?php echo e($marsyi->title); ?>

                                        </h5>
                                        <p>
                                            <?php echo e($marsyi->description); ?>

                                        </p>
                                        <div class="options">
                                            <h6>
                                                IDR. <?php echo e($marsyi->price); ?>

                                            </h6>
                                            <a
                                                href="https://wa.me/6287766304421?text=<?php echo e(urlencode("assalamualaikum min, saya mau pesan product '" . $marsyi->title . "' dengan harga Rp." . $marsyi->price)); ?>">
                                                <i class="fa fa-cart-shopping" style="color:#EBF4F6;"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="btn-box">
                    <a href="/catalogue">
                        View More
                    </a>
                </div>
            </div>
        </div>
    </section>


    <section id="client" class="client_section layout_padding-bottom">
        <div class="container">
            <div class="heading_container heading_center psudo_white_primary mb_45">
                <h2>
                    Apa yang mereka katakan?
                </h2>
            </div>
            <div class="carousel-wrap row ">
                <div class="owl-carousel client_owl-carousel">
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marsyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="box">
                                <div class="detail-box">
                                    <p>
                                        <?php echo e($marsyi->said); ?>

                                    </p>
                                    <h6>
                                        <?php echo e($marsyi->title); ?>

                                    </h6>
                                    <p>
                                        - <?php echo e($marsyi->name); ?>

                                    </p>
                                </div>
                                <div class="img-box">
                                    <img src="<?php echo e(asset('storage/customer/' . $marsyi->image)); ?>" alt=""
                                        class="box-img">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="about_section layout_padding">
        <div class="container  ">

            <div class="row">
                <div class="col-md-6 ">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/design.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-box">
                        <div class="heading_container">
                            <h2>
                                Santripasir Merchandise
                            </h2>
                        </div>
                        <p>
                            There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration
                            in some form, by injected humour, or randomised words which don't look even slightly
                            believable. If you
                            are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything
                            embarrassing hidden in
                            the middle of text. All
                        </p>
                        <a href="">
                            Tata cara pemesanan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $attributes = $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $component = $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/Home.blade.php ENDPATH**/ ?>