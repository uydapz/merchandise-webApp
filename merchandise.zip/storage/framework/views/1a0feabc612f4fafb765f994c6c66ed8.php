<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve(['title' => $title ?? ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('DashboardLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginala71525cf291a399d842fbc5cc27d6b37 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala71525cf291a399d842fbc5cc27d6b37 = $attributes; } ?>
<?php $component = App\View\Components\CheckValidate::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('CheckValidate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CheckValidate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala71525cf291a399d842fbc5cc27d6b37)): ?>
<?php $attributes = $__attributesOriginala71525cf291a399d842fbc5cc27d6b37; ?>
<?php unset($__attributesOriginala71525cf291a399d842fbc5cc27d6b37); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala71525cf291a399d842fbc5cc27d6b37)): ?>
<?php $component = $__componentOriginala71525cf291a399d842fbc5cc27d6b37; ?>
<?php unset($__componentOriginala71525cf291a399d842fbc5cc27d6b37); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
    <?php echo $__env->make('components.molecules.AddmodalCatalogue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (isset($component)) { $__componentOriginal62f705a3ab1369d00b2b16507893f7cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62f705a3ab1369d00b2b16507893f7cf = $attributes; } ?>
<?php $component = App\View\Components\DataTables::resolve(['tabel' => $title,'jenis' => 'multi-filter-select','modal' => 'AddModalCatalogue'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('DataTables'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DataTables::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <thead>
            <tr>
                <th>No</th>
                <th>Image</th>
                <th>Title</th>
                <th>Link</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Image</th>
                <th>Title</th>
                <th>Link</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $catalogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><img src="<?php echo e(asset('storage/catalogue/' . $c->image)); ?>" class="img-fluid" style="max-width: 20%"
                            alt=""></td>
                    <td><?php echo e($c->title); ?></td>
                    <td><?php echo e($c->link); ?></td>
                    <td><?php echo e($c->description); ?></td>
                    <td><?php echo e($c->price); ?></td>
                    <td><?php echo e($c->category); ?></td>
                    <?php if (isset($component)) { $__componentOriginalafb56f7849ee92993ca18d80506efe0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalafb56f7849ee92993ca18d80506efe0b = $attributes; } ?>
<?php $component = App\View\Components\ButtonAction::resolve(['modal' => 'EditModalCatalogue-'.e($c->id).'','delete' => 'catalogue/'.e($c->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('buttonAction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ButtonAction::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalafb56f7849ee92993ca18d80506efe0b)): ?>
<?php $attributes = $__attributesOriginalafb56f7849ee92993ca18d80506efe0b; ?>
<?php unset($__attributesOriginalafb56f7849ee92993ca18d80506efe0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalafb56f7849ee92993ca18d80506efe0b)): ?>
<?php $component = $__componentOriginalafb56f7849ee92993ca18d80506efe0b; ?>
<?php unset($__componentOriginalafb56f7849ee92993ca18d80506efe0b); ?>
<?php endif; ?>
                    <?php echo $__env->make('components.molecules.EditModalCatalogue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62f705a3ab1369d00b2b16507893f7cf)): ?>
<?php $attributes = $__attributesOriginal62f705a3ab1369d00b2b16507893f7cf; ?>
<?php unset($__attributesOriginal62f705a3ab1369d00b2b16507893f7cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62f705a3ab1369d00b2b16507893f7cf)): ?>
<?php $component = $__componentOriginal62f705a3ab1369d00b2b16507893f7cf; ?>
<?php unset($__componentOriginal62f705a3ab1369d00b2b16507893f7cf); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\merchandise\resources\views/components/pages/AdminCatalogue.blade.php ENDPATH**/ ?>